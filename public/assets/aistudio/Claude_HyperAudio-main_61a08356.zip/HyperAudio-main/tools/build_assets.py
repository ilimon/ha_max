#!/usr/bin/env python3
import hashlib,json,os,re,struct,sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEV={'iem':('IEM','KZ EDX Pro'),'speaker':('Speaker','Redmi 12')}
ORDER={'vdc':0,'irs':1,'eel':2}
def irs(b):
    if b[:4]!=b'RIFF' or b[8:12]!=b'WAVE':return None
    o=12;f=None
    while o+8<=len(b):
        t=b[o:o+4];n=struct.unpack('<I',b[o+4:o+8])[0]
        if t==b'fmt ':f=struct.unpack('<HHIIHH',b[o+8:o+24])
        if t==b'data' and f:
            n=min(n,len(b)-o-8);fm,ch,sr,_,ba,bits=f
            return dict(fmt=fm,ch=ch,sr=sr,bits=bits,taps=n//ba if ba else 0,data=b[o+8:o+8+n])
        o+=8+n+(n&1)
def irs_info(b):
    d=irs(b)
    if not d:return 'Unreadable WAV',False
    lay={1:'mono',2:'stereo',4:'4-ch true stereo'}.get(d['ch'],f"{d['ch']}-ch")
    ok=False
    if d['fmt']==3 and d['bits']==32:
        import array
        a=array.array('f');a.frombytes(d['data'][:len(d['data'])//4*4])
        fin=all(x==x and abs(x)!=float('inf') for x in a)
        pk=max((abs(x) for x in a),default=9);tl=max((abs(x) for x in a[-256*d['ch']:]),default=9)
        ok=fin and pk<=1 and tl<=1e-4
    return f"{lay} · {d['taps']} taps · {d['sr']/1000:g} kHz",ok
def vdc_info(t):
    L=[re.match(r'SR_(\d+):(.+)',l.strip()) for l in t.strip().splitlines()]
    if not L or any(m is None for m in L):return 'Unreadable DDC',False
    ok=True;idn=True;n=0
    for m in L:
        v=[float(x) for x in m.group(2).split(',')]
        if len(v)%5:return 'Unreadable DDC',False
        S=[v[i:i+5] for i in range(0,len(v),5)];n=len(S)
        for b0,b1,b2,a1,a2 in S:
            if [b0,b1,b2,a1,a2]!=[1,0,0,0,0]:idn=False
            if not(abs(a2)<1 and abs(a1)<1-a2):ok=False
    return ('identity · pass-through' if idn else f'{n} biquad'+('s' if n>1 else ''))+f' · {len(L)} rates',ok
def eel_info(t):
    m=re.search(r'^desc:\s*(.+)$',t,re.M)
    ok=len(re.findall(r'^@init',t,re.M))==1 and len(re.findall(r'^@sample',t,re.M))==1 and bool(m)
    return (m.group(1).strip() if m else 'No desc line'),ok
meta=json.load(open(f'{ROOT}/data/assets.meta.json')) if os.path.exists(f'{ROOT}/data/assets.meta.json') else {}
def entry(p):
    b=open(f'{ROOT}/{p}','rb').read();f=os.path.basename(p);e=f.rsplit('.',1)[1]
    info,ok=irs_info(b) if e=='irs' else vdc_info(b.decode('utf-8','replace')) if e=='vdc' else eel_info(b.decode('utf-8','replace'))
    m=meta.get(p,{})
    return dict(name=f,path=p,type=e,size=len(b),sha=hashlib.sha256(b).hexdigest(),info=info,status='Numerically qualified' if ok else 'Experimental',warn=m.get('warn',''),note=m.get('note',''))
sets=[];coreset={}
for d,(dn,pn) in DEV.items():
    coreset[d]=sorted((entry(f'{d}/core/{f}') for f in os.listdir(f'{ROOT}/{d}/core')),key=lambda x:ORDER[x['type']])
    lib=f'{ROOT}/{d}/library'
    for s in sorted(os.listdir(lib)):
        fl=sorted((entry(f'{d}/library/{s}/{f}') for f in os.listdir(f'{lib}/{s}')),key=lambda x:(ORDER[x['type']],x['name']))
        n=re.search(r'\d+',s);sets.append(dict(dev=d,id=s,title=s.upper().replace('-',' · ') if not n else s.replace('-',' · '),n=int(n.group()) if n else -1,files=fl))
for s in sets:
    for f in s['files']:
        f['pairs']=[g['name'] for g in s['files'] if g['type']!=f['type']]
sets.sort(key=lambda s:(s['dev']!='iem',-s['n'],s['id']))
json.dump(dict(devices={k:v[1] for k,v in DEV.items()},core=coreset,sets=sets),open(f'{ROOT}/data/assets.json','w'),separators=(',',':'),ensure_ascii=False)
core=[f'{d}/core/{f}' for d in DEV for f in sorted(os.listdir(f'{ROOT}/{d}/core'))]
out=[f"{hashlib.sha256(open(f'{ROOT}/{p}','rb').read()).hexdigest()}  {p}" for p in core+[f['path'] for s in sets for f in s['files']]]
open(f'{ROOT}/SHA256SUMS','w').write('\n'.join(out)+'\n')
print(len(sets),'sets',sum(len(s['files']) for s in sets),'files')
