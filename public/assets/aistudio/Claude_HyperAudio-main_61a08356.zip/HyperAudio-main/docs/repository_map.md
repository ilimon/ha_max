# HyperAudio · Repository Map

An annotated map of every tracked file in the HyperAudio repository. 

---

## Directory Layout

```text
HyperAudioo/
├── README.md · index.html · ATTRIBUTION.md · SHA256SUMS
├── LICENSE · LICENSE.md · LICENSE-MIT · LICENSE-CC-BY-SA-4.0
├── robots.txt · site.webmanifest · sitemap.xml
├── iem/        core/ (default export), library/ (all versions), guide, report
├── speaker/    core/ (default export), library/ (all versions), guide, report
├── tools/      build_assets.py (writes data/assets.json and SHA256SUMS)
├── docs/       reference, method and test documents
├── data/       raw measurements, targets, method note
├── addons/     optional IRS files and reference presets
└── assets/     site code, images, fonts, harness reports
```

---

Root Files

File Purpose
README.md Main project overview and quick start guide.
index.html The browser site (HyperAudio site).
ATTRIBUTION.md Third-party sources and credits.
LICENSE.md License summary (points to MIT and CC BY-SA).
SHA256SUMS Checksum manifest for shipped assets.
robots.txt Crawler rules for the web app.

---

Hardware Directories

Directory Contents
iem/ IEM assets: core/ trio, library/<version>/ sets, setup guide, technical report.
speaker/ Speaker assets: core/ trio, library/<version>/ sets, setup guide, technical report.
tools/ build_assets.py regenerates data/assets.json and SHA256SUMS from the files.

---

Documentation and Data

Directory Contents
docs/ Architecture references, style guide, methodology, and test reports.
data/ Library manifest (assets.json, assets.meta.json), raw frequency response measurements and custom target curves.
addons/ Optional IRS files (BBE, EFOtech) and EasyEffects JSON references.
assets/ Site assets including fonts, images, logos, and the verification harness graphics.

---

<div align="center">
<sub>Designed &amp; tuned by <b>Noushad M.</b> · © 2026</sub>
</div>
