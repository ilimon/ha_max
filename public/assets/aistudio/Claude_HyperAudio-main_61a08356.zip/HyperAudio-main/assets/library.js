(async()=>{
const root=document.getElementById('lib');
if(!root)return;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const kb=n=>n<1024?n+' B':(n/1024).toFixed(1)+' KB';
const IC={vdc:'sliders',irs:'wave',eel:'code'};
const card=f=>{
const w=[f.warn,/4-ch/.test(f.info)?'4-channel IRS. Needs a host that loads true-stereo IRS.':''].filter(Boolean);
return`<article class="lcard"><header><span class="tag ${f.type}"><svg class="i xs" aria-hidden="true"><use href="#i-${IC[f.type]}"/></svg>${f.type.toUpperCase()}</span><span class="chip ${f.status[0]=='N'?'ok':'warn'}">${f.status}</span></header><b class="lname">${esc(f.name)}</b><p class="linfo">${esc(f.info)}</p><p class="lpair">Pairs with ${f.pairs.length?f.pairs.map(esc).join(', '):'no other file'}</p>${w.map(x=>`<p class="lwarn">${esc(x)}</p>`).join('')}<footer><span class="lmeta">${kb(f.size)}</span><button class="lhash" type="button" data-h="${f.sha}" title="Copy SHA-256">${f.sha.slice(0,10)}<svg class="i xs" aria-hidden="true"><use href="#i-copy"/></svg></button><a class="ldl" href="${esc(f.path)}" download aria-label="Download ${esc(f.name)}"><svg class="i" aria-hidden="true"><use href="#i-download"/></svg></a></footer></article>`;
};
let D;
try{
D=await(await fetch('data/assets.json')).json();
}catch(e){
root.insertAdjacentHTML('beforeend','<p class="x-warn"><b>Library unavailable.</b> data/assets.json could not be loaded.</p>');
return;
}
const html=Object.keys(D.devices).map(d=>{
const S=D.sets.filter(s=>s.dev==d);
return`<section class="ldev"><h3 class="x-sub">${d=='iem'?'IEM':'Speaker'} · ${esc(D.devices[d])}<small>${S.length} sets · ${S.reduce((n,s)=>n+s.files.length,0)} files</small></h3>${S.map((s,i)=>`<details class="lset"${i?'':' open'}><summary><span><b>${esc(s.title)}</b><small>${['vdc','irs','eel'].map(k=>[k,s.files.filter(f=>f.type==k).length]).filter(x=>x[1]).map(x=>x[0].toUpperCase()+(x[1]>1?' ×'+x[1]:'')).join(' · ')}</small></span><svg class="i chev" aria-hidden="true"><use href="#i-chev"/></svg></summary><div class="lbody"><button class="btn ghost lset-dl" type="button" data-set="${d}/${s.id}"><svg class="i" aria-hidden="true"><use href="#i-download"/></svg>Download set</button><div class="lgrid">${s.files.map(card).join('')}</div></div></details>`).join('')}</section>`;
}).join('');
root.insertAdjacentHTML('beforeend',html);
root.addEventListener('click',e=>{
const h=e.target.closest('.lhash');
if(h){
(navigator.clipboard?navigator.clipboard.writeText(h.dataset.h):Promise.reject()).then(()=>toast('SHA-256 copied'),()=>toast('Copy failed',1));
return;
}
const b=e.target.closest('.lset-dl');
if(!b)return;
const as=[...b.parentNode.querySelectorAll('.ldl')];
as.forEach((a,i)=>setTimeout(()=>a.click(),i*350));
toast(`Downloading ${as.length} files`);
});
})();
