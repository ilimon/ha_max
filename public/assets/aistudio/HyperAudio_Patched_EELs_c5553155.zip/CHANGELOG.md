# Patched EELs (offline VM tested only; not device tested)
All six: NaN/Inf input guard; 4x true-peak detector (residual <= +0.19 dB over ceiling on sweep, was +2.92); ceiling slider max -0.3 dBFS; false "Google" attributions removed.
IEM v4 / v10, SPK v8 / v10: limiter replaced by the EDX_HD sliding-min + moving-average core (no clamp reliance, NaN safe).
EDX_HD: dead Harmonic Warmth slider removed. IEM v10: ISP toggle removed (always on).
SPK v8: empty bypass branch fixed (compile); Dialogue Boost default 20 -> 0 (was +2 dB on mono).
SPK v10: bass harmonic DC removed (20 Hz HP), rectifier term dropped; compressor uses 20 ms peak-hold detector (THD+N -55.7 -> -92.5 dB). Makeup default 10 dB unchanged (+1.9 dB at 0.3 FS).
Not fixed here (file-level, not EEL): SPK_v6 IRS+VDC double high-pass, IEM V4 +9.7 dB chain, V8 L/R IRS mismatch, V8/V10 bank mismatch, IEM V10 no crossfeed.
